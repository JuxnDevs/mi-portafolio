import React, { useState, useRef, useEffect } from 'react';
import { StatusBar, Text, SafeAreaView, TextInput, TouchableOpacity, StyleSheet, Alert, View, Animated, Image } from 'react-native';

export default function App() {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [activeButton, setActiveButton] = useState(null);
  const [currentScreen, setCurrentScreen] = useState('home');
  const [selectedInfo, setSelectedInfo] = useState({ text: '', percentage: 0, image: '' });

  const fadeAnim = useRef(new Animated.Value(0)).current;
  const scaleAnim = useRef(new Animated.Value(0.8)).current;
  const slideAnim = useRef(new Animated.Value(-100)).current;

  const texts = ['Seguimiento de obras', 'Facturación', 'Remisiones', 'Control de obra', 'Suministro de material'];
  const customTexts = [
    'Desaladora San Quintín',
    'Líneas de agua potable San Marino',
    'Alumbrado público Morelos',
    'Remodelación Casa María',
    'Laboratorio UABC',
  ];
  const percentages = [56, 90, 20, 75, 15];
  const images = [
    'https://snack-code-uploads.s3.us-west-1.amazonaws.com/~asset/33cd5ef1d2cc791d27da92956a5b79f0',
    'https://snack-code-uploads.s3.us-west-1.amazonaws.com/~asset/35276dfdf3235c7cc23e334b3ad1a4c1',
    'https://snack-code-uploads.s3.us-west-1.amazonaws.com/~asset/8b8ab85cee9443e9f9f16d8d91dfe162',
    'https://snack-code-uploads.s3.us-west-1.amazonaws.com/~asset/fc8c0ad4d7fe503100b9dbe578a78654',
    'https://snack-code-uploads.s3.us-west-1.amazonaws.com/~asset/69e60b5c2f03b15c8ec470df89436c4c',
  ];

  const handleLogin = () => {
    if (username === 'Araceli' || (username === 'Admin' && password === '1234')) {
      setIsLoggedIn(true);
      Alert.alert(`Bienvenid@ ${username}`);
      Animated.spring(scaleAnim, { toValue: 1, useNativeDriver: true }).start();
    } else {
      Alert.alert('Error', 'Usuario o contraseña incorrectos');
    }
  };

  const handleLogout = () => {
    setIsLoggedIn(false);
    setUsername('');
    setPassword('');
    setCurrentScreen('home');
  };

  useEffect(() => {
    Animated.timing(fadeAnim, { toValue: 1, duration: 1500, useNativeDriver: true }).start();
    Animated.spring(slideAnim, { toValue: 0, useNativeDriver: true }).start();
  }, []);

  const goToMenu = () => {
    setCurrentScreen('customMenu');
  };

  const goBackToMenu = () => {
    setCurrentScreen('menu');
    setSelectedInfo({ text: '', percentage: 0, image: '' });
  };

  const goToDetailScreen = (index) => {
    setSelectedInfo({ text: customTexts[index], percentage: percentages[index], image: images[index] });
    setCurrentScreen('detail');
  };

  const goBackToCustomMenu = () => {
    setCurrentScreen('customMenu');
  };

  const Header = ({ onBack }) => (
    <View style={styles.header}>
      <TouchableOpacity style={styles.logoutButton} onPress={onBack}>
        <Image
          source={{ uri: 'https://th.bing.com/th/id/R.ad2c20cbb19e1930132d6918c2b6a0bd?rik=scBhIGelEJC%2fAw&pid=ImgRaw&r=0' }}
          style={styles.logoutImage}
        />
      </TouchableOpacity>
      <View style={styles.headerTextContainer}>
        <Text style={styles.headerTextBlack}>Micl</Text>
        <Text style={styles.headerTextBlue}>App</Text>
      </View>
    </View>
  );

  const loginBackground = (
    <SafeAreaView style={styles.container}>
      <Animated.Text style={[styles.title, { opacity: fadeAnim }]}>
        <Text style={styles.blackText}>Micl</Text>
        <Text style={styles.blueText}>App</Text>
      </Animated.Text>

      <View style={styles.inputContainer}>
        <Animated.View style={{ transform: [{ translateY: slideAnim }] }}>
          <TextInput
            style={styles.input}
            placeholder="Usuario"
            placeholderTextColor="#333"
            value={username}
            onChangeText={setUsername}
          />
        </Animated.View>
        <Animated.View style={{ transform: [{ translateY: slideAnim }] }}>
          <TextInput
            style={styles.input}
            placeholder="Contraseña"
            placeholderTextColor="#333"
            value={password}
            onChangeText={setPassword}
            secureTextEntry={true}
          />
        </Animated.View>
      </View>

      <TouchableOpacity style={styles.button} onPress={handleLogin}>
        <Animated.Text style={[styles.buttonText, { transform: [{ scale: scaleAnim }] }]}>Iniciar Sesión</Animated.Text>
      </TouchableOpacity>
      <Animated.Image
        source={{ uri: 'https://snack-code-uploads.s3.us-west-1.amazonaws.com/~asset/af833d65d65bd1ad9ae39fd3131aa9c5' }}
        style={[styles.image1, { transform: [{ scale: scaleAnim }] }]}
      />
    </SafeAreaView>
  );

  const menuScreen = (
    <>
      <Header onBack={handleLogout} />
      <SafeAreaView style={styles.container}>
        {texts.map((text, index) => (
          <TouchableOpacity
            key={index}
            style={[styles.minimalBar, activeButton === index && styles.activeBar]}
            onPress={() => {
              setActiveButton(index);
              if (text === 'Seguimiento de obras') {
                goToMenu();
              } else {
                setSelectedInfo({ text, percentage: percentages[index], image: images[index] });
              }
            }}
          >
            <Animated.Text style={[styles.barText, { opacity: fadeAnim }]}>{text}</Animated.Text>
          </TouchableOpacity>
        ))}
        <Animated.Image
          source={{ uri: 'https://snack-code-uploads.s3.us-west-1.amazonaws.com/~asset/af833d65d65bd1ad9ae39fd3131aa9c5' }}
          style={[styles.image, { transform: [{ scale: scaleAnim }] }]}
        />
      </SafeAreaView>
    </>
  );

  const customMenuScreen = (
    <>
      <Header onBack={goBackToMenu} />
      <SafeAreaView style={styles.container}>
        {customTexts.map((text, index) => (
          <TouchableOpacity key={index} style={styles.minimalBar} onPress={() => goToDetailScreen(index)}>
            <Text style={styles.barText}>{text}</Text>
          </TouchableOpacity>
        ))}
      </SafeAreaView>
    </>
  );

  const detailScreen = (
    <>
      <Header onBack={goBackToCustomMenu} />
      <SafeAreaView style={styles.container}>
        <Text style={styles.infoText}>{selectedInfo.text}</Text>
        <Text style={styles.infoText}>Avance: {selectedInfo.percentage}%</Text>
        <Image source={{ uri: selectedInfo.image }} style={styles.infoImage} />
      </SafeAreaView>
    </>
  );

  if (isLoggedIn) {
    if (currentScreen === 'customMenu') return customMenuScreen;
    if (currentScreen === 'detail') return detailScreen;
    return menuScreen;
  }

  return loginBackground;
}


const styles = StyleSheet.create({
    container: {
    flex: 1,
    justifyContent: 'flex-start',
    alignItems: 'center',
    paddingTop: 50,
    paddingHorizontal: 20,
    backgroundColor: 'white',
  },
  header: {
    width: '100%',
    paddingTop: StatusBar.currentHeight,
    paddingVertical: 15,
    backgroundColor: '#61b4c4',
    alignItems: 'center',
    justifyContent: 'center',
    flexDirection: 'row',
    marginBottom: 40,
    height: 100,
  },
  headerTextContainer: {
    position: 'absolute',
    left: '50%',
    paddingTop: 15,
    transform: [{ translateX: -50 }],
    flexDirection: 'row',
  },
  headerTextBlue: {
    color: '#FFFFFF',
    fontSize: 34,
    paddingTop: 20,
    fontWeight: 'bold',
  },
  headerTextBlack: {
    color: '#333',
    fontSize: 34,
    fontWeight: 'bold',
    paddingTop: 20,
  },
  title: {
    fontSize: 40,
    fontWeight: 'bold',
    textAlign: 'center',
    marginBottom: 20,
    color: '#333',
  },
  blackText: {
    color: '#333',
  },
  blueText: {
    color: '#61b4c4',
  },
  inputContainer: {
    width: '100%',
    alignItems: 'center',
  },
  input: {
    height: 50,
    backgroundColor: '#e8e8e8',
    borderRadius: 22,
    width: 340,
    paddingHorizontal: 15,
    marginBottom: 16,
    fontSize: 16,
    color: '#333',
  },
  button: {
    backgroundColor: '#61b4c4',
    borderRadius: 22,
    paddingVertical: 12,
    paddingHorizontal: 40,
    alignItems: 'center',
    marginVertical: 10,
  },
  buttonText: {
    color: '#fff',
    fontSize: 18,
  },
  image1: {
    width: 200,
    height: 200,
    marginTop: 20,
    resizeMode: 'contain',
  },
  image: {
    width: 200,
    height: 200,
    marginTop: 20,
    resizeMode: 'contain',
  },
  minimalBar: {
    width: '90%',
    paddingVertical: 12,
    marginVertical: 8,
    borderRadius: 10,
    backgroundColor: '#e8e8e8',
    alignItems: 'center',
  },
  activeBar: {
    backgroundColor: '#61b4c4',
  },
  barText: {
    fontSize: 16,
    color: '#333',
  },
  logoutButton: {
    paddingTop: 15,
    marginRight: 300,
    paddingHorizontal: 10,
  },
  logoutImage: {
    width: 60,
    height: 60,
  },
  infoContainer: {
    alignItems: 'center',
    marginBottom: 20,
  },
  infoText: {
    fontSize: 18,
    color: '#333',
  },
  infoImage: {
    width: 100,
    height: 100,
    marginTop: 10,
  },
    infoImage: {
    width: 400,  // Cambia a un tamaño mayor
    height: 400, // Cambia a un tamaño mayor
    marginTop: 20,
    resizeMode: 'contain',
    borderRadius: 20, // Añade borde redondeado opcional
  },

  infoText: {
    fontSize: 40, // Tamaño de fuente más grande
    color: '#333',
    fontWeight: 'bold', // Añade un peso de fuente
    fontFamily: 'sans-serif-condensed', // Cambia la fuente
    textAlign: 'center',
    marginBottom: 8,
  },

  /* Aquí va todo el estilo */
});