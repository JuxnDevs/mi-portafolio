import React from 'react';
import { View, Text } from 'react-native';

const MenuScreen = () => {
  return (
    <View>
      <Text>Bienvenido al Menú</Text>
    </View>
  );
};

export default MenuScreen;
